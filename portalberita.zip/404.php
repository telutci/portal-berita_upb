<?php include 'header.php';?>
<div class="container-fluid">
	<div class="row">
		<div class="container konten-wrapper">
			<div class="panel panel-default">
				<div class="panel-body not-found">
					<h1>404</h1>
					<h2>Oops, Halaman Tidak Ditemukan!</h2>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include 'footer.php';