<?php
$base_url = 'http://localhost/portalberita/'; //URL utama website